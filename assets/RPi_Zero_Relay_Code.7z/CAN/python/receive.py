import RPi.GPIO as GPIO
import serial
import os
import can
from can import Message
import time

GPIO.setmode(GPIO.BCM)

GPIO.setup(5,GPIO.OUT)
GPIO.setup(6,GPIO.OUT)
GPIO.setup(13,GPIO.OUT)
GPIO.setup(16,GPIO.OUT)
GPIO.setup(19,GPIO.OUT)
GPIO.setup(20,GPIO.OUT)

GPIO.output(5,GPIO.LOW)
GPIO.output(6,GPIO.LOW)
GPIO.output(13,GPIO.LOW)
GPIO.output(16,GPIO.LOW)
GPIO.output(19,GPIO.LOW)
GPIO.output(20,GPIO.LOW)


os.system('sudo ip link set can0 type can bitrate 100000')
os.system('sudo ifconfig can0 up')

can0 = can.interface.Bus(channel = 'can0', bustype = 'socketcan_ctypes')# socketcan_native

# msg = can.Message(arbitration_id=0x123, data=[0, 1, 2, 3, 4, 5, 6, 7], extended_id=False)


i = 0
b = '\n'
fun = 0xff
fun1 = 0x00
buff = [0,0]

msg1 = can.Message(arbitration_id=0x123, data=[0], extended_id=False)
can0.send(msg1)

print("You can always receive data, press Ctrl + C to exit\r\n")
while True:
    msg = can0.recv(100)
    if msg is None:
        print('Timeout occurred, no message.')
        
    time.sleep(0.1)
    data = msg.data
    print("\nThe data received is : "),data
    i = 0
    for b in data:
        if b == 49 :
            if fun & 0x01 == 0:
                print("Turn off Relay 1")
                fun = fun | 0x01
                fun1 = fun1 & 0xfe
                GPIO.output(5,GPIO.LOW)
            
        elif b == 50 :
            if fun & 0x02 == 0:
                print("Turn off Relay 2")
                fun = fun | 0x02
                fun1 = fun1 & 0xfd
                GPIO.output(6,GPIO.LOW)
            
        elif b == 51 :
            if fun & 0x04 == 0:
                print("Turn off Relay 3")
                fun = fun | 0x04
                fun1 = fun1 & 0xfb
                GPIO.output(13,GPIO.LOW)
            
        elif b == 52 :
            if fun & 0x08 == 0:
                print("Turn off Relay 4")
                fun = fun | 0x08
                fun1 = fun1 & 0xf7
                GPIO.output(16,GPIO.LOW)
            
        elif b == 53 :
            if fun & 0x10 == 0:
                print("Turn off Relay 5")
                fun = fun | 0x10
                fun1 = fun1 & 0xef
                GPIO.output(19,GPIO.LOW)
            
        elif b == 54 :
            if fun & 0x20 == 0:
                print("Turn off Relay 6")
                fun = fun | 0x20
                fun1 = fun1 & 0xdf
                GPIO.output(20,GPIO.LOW)
            
        elif b == 97 :
            if fun1 & 0x01 == 0:
                print("Turn on Relay 1")
                fun1 = fun1 | 0x01
                fun = fun & 0xfe
                GPIO.output(5,GPIO.HIGH)
            
        elif b == 98 :
            if fun1 & 0x02 == 0:
                print("Turn on Relay 2")
                fun1 = fun1 | 0x02
                fun = fun & 0xfd
                GPIO.output(6,GPIO.HIGH)
            
        elif b == 99 :
            if fun1 & 0x04 == 0:
                print("Turn on Relay 3")
                fun1 = fun1 | 0x04
                fun = fun & 0xfb
                GPIO.output(13,GPIO.HIGH)
            
        elif b == 100 :
            if fun1 & 0x08 == 0:
                print("Turn on Relay 4")
                fun1 = fun1 | 0x08
                fun = fun & 0xf7
                GPIO.output(16,GPIO.HIGH)
            
        elif b == 101 :
            if fun1 & 0x10 == 0:
                print("Turn on Relay 5")
                fun1 = fun1 | 0x10
                fun = fun & 0xef
                GPIO.output(19,GPIO.HIGH)
            
        elif b == 102 :
            if fun1 & 0x20 == 0:
                print("Turn on Relay 6")
                fun1 = fun1 | 0x20
                fun = fun & 0xdf
                GPIO.output(20,GPIO.HIGH)
            
        else :
            i = i

    
    msg1 = can.Message(arbitration_id=0x123, data=data, extended_id=False)
    can0.send(msg1)
    
    buff[0] = fun
    buff[1] = fun1
    
    time.sleep(1)
    
    msg1 = can.Message(arbitration_id=0x123, data=buff, extended_id=False)
    can0.send(msg1)
    


os.system('sudo ifconfig can0 down')
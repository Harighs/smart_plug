# -*- coding:utf-8 -*-
import RPi.GPIO as GPIO
import serial
import time


GPIO.setmode(GPIO.BCM)

GPIO.setup(5,GPIO.OUT)
GPIO.setup(6,GPIO.OUT)
GPIO.setup(13,GPIO.OUT)
GPIO.setup(16,GPIO.OUT)
GPIO.setup(19,GPIO.OUT)
GPIO.setup(20,GPIO.OUT)

GPIO.output(5,GPIO.LOW)
GPIO.output(6,GPIO.LOW)
GPIO.output(13,GPIO.LOW)
GPIO.output(16,GPIO.LOW)
GPIO.output(19,GPIO.LOW)
GPIO.output(20,GPIO.LOW)


ser = serial.Serial("/dev/ttyAMA0",115200,timeout=0.01) #receive data once every 0.01S 
print ser.portstr

ser.flushInput()

data = ""
i = 0
b = '\n'
fun = 0x0000
print("You can always receive data, press Ctrl + C to exit\r\n")
while 1: 
    while ser.inWaiting() > 0:
        data = ser.readline()
    if data != "":
        print("\nThe data received is : "),data
        ser.write("\nThe data received back is : " + data + "\r\n")
        data = data + b
        while data[i] != '\n':
            if data[i] == '1' :
                if fun & 0x0001 == 0:
                    print("Turn off Relay 1")
                    ser.write("Turn off Relay 1\r\n")
                    fun = fun | 0x0001
                    GPIO.output(5,GPIO.LOW)
                
            elif data[i] == '2' :
                if fun & 0x0002 == 0:
                    print("Turn off Relay 2")
                    ser.write("Turn off Relay 2\r\n")
                    fun = fun | 0x0002
                    GPIO.output(6,GPIO.LOW)
                
            elif data[i] == '3' :
                if fun & 0x0004 == 0:
                    print("Turn off Relay 3")
                    ser.write("Turn off Relay 3\r\n")
                    fun = fun | 0x0004
                    GPIO.output(13,GPIO.LOW)
                
            elif data[i] == '4' :
                if fun & 0x0008 == 0:
                    print("Turn off Relay 4")
                    ser.write("Turn off Relay 4\r\n")
                    fun = fun | 0x0008
                    GPIO.output(16,GPIO.LOW)
                
            elif data[i] == '5' :
                if fun & 0x0010 == 0:
                    print("Turn off Relay 5")
                    ser.write("Turn off Relay 5\n")
                    fun = fun | 0x0010
                    GPIO.output(19,GPIO.LOW)
                
            elif data[i] == '6' :
                if fun & 0x0020 == 0:
                    print("Turn off Relay 6")
                    ser.write("Turn off Relay 6\n")
                    fun = fun | 0x0020
                    GPIO.output(20,GPIO.LOW)
                
            elif data[i] == 'a' :
                if fun & 0x0040 == 0:
                    print("Turn on Relay 1")
                    ser.write("Turn on Relay 1\n")
                    fun = fun | 0x0040
                    GPIO.output(5,GPIO.HIGH)
                
            elif data[i] == 'b' :
                if fun & 0x0080 == 0:
                    print("Turn on Relay 2")
                    ser.write("Turn on Relay 2\n")
                    fun = fun | 0x0080
                    GPIO.output(6,GPIO.HIGH)
                
            elif data[i] == 'c' :
                if fun & 0x0100 == 0:
                    print("Turn on Relay 3")
                    ser.write("Turn on Relay 3\n")
                    fun = fun | 0x0100
                    GPIO.output(13,GPIO.HIGH)
                
            elif data[i] == 'd' :
                if fun & 0x0200 == 0:
                    print("Turn on Relay 4")
                    ser.write("Turn on Relay 4\n")
                    fun = fun | 0x0200
                    GPIO.output(16,GPIO.HIGH)
                
            elif data[i] == 'e' :
                if fun & 0x0400 == 0:
                    print("Turn on Relay 5")
                    ser.write("Turn on Relay 5\n")
                    fun = fun | 0x0400
                    GPIO.output(19,GPIO.HIGH)
                
            elif data[i] == 'f' :
                if fun & 0x0400 == 0:
                    print("Turn on Relay 6")
                    ser.write("Turn on Relay 6\n")
                    fun = fun | 0x0400
                    GPIO.output(20,GPIO.HIGH)
                
            else :
                i = i
        
            i = i + 1
    
        
        data = ""
        ser.write("END\n\n")
        i=0
        fun = 0
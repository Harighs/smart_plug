# -*- coding:utf-8 -*-
import RPi.GPIO as GPIO
import serial
import time


ser = serial.Serial("/dev/ttyAMA0",115200,timeout=1) 
print ser.portstr
ser.flushInput()

print("You can always send data, press Ctrl + C to exit")
print("Send \"ABCDEF\" to open relays 1, 2, 3, 4, 5 and 6 respectively\r\n")
print("Send \"123456\" to close relays 1, 2, 3, 4, 5 and 6 respectivelyy\r\n")

data = ""
while 1:
    strInput = raw_input('Enter some data:')  
    ser.write(strInput)
    time.sleep(0.1)
    while ser.inWaiting() > 0:
        data = ser.readline()
        if data != "":
            print(data)
            data = ""
        

ser.flush()



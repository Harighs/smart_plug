#include <wiringSerial.h>
#include <wiringPi.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <strings.h>
#include <sys/time.h>

#include <stdlib.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <linux/can.h>
#include <linux/can/raw.h>


int main()
{
    int ret;
    int s, nbytes;
    struct sockaddr_can addr;
    struct ifreq ifr;
    struct can_frame frame;
    memset(&frame, 0, sizeof(struct can_frame));

    system("sudo ip link set can0 type can bitrate 100000");
    system("sudo ifconfig can0 up");
    printf("this is a can send demo\r\n");
        
    //1.Create socket
    s = socket(PF_CAN, SOCK_RAW, CAN_RAW);
    if (s < 0) {
        perror("socket PF_CAN failed");
        return 1;
    }
    
    //2.Specify can0 device
    strcpy(ifr.ifr_name, "can0");
    ret = ioctl(s, SIOCGIFINDEX, &ifr);
    if (ret < 0) {
        perror("ioctl failed");
        return 1;
    }
    
    //3.Bind the socket to can0
    addr.can_family = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;
    ret = bind(s, (struct sockaddr *)&addr, sizeof(addr));
    if (ret < 0) {
        perror("bind failed");
        return 1;
    }
	
	struct can_filter rfilter[1];
    rfilter[0].can_id = 0x123;
    rfilter[0].can_mask = CAN_SFF_MASK;
    setsockopt(s, SOL_CAN_RAW, CAN_RAW_FILTER, &rfilter, sizeof(rfilter));
    
    //4.Disable filtering rules, do not receive packets, only send
    setsockopt(s, SOL_CAN_RAW, CAN_RAW_FILTER, NULL, 0);

    //5.Set send data
    frame.can_id = 0x123;
    frame.can_dlc = 8;
    frame.data[0] = 0;
    frame.data[1] = 10;
	frame.data[2] = 10;
	frame.data[3] = 10;
	frame.data[4] = 10;
	frame.data[5] = 10;
	frame.data[6] = 10;
	frame.data[7] = 10;
	
    printf("can_id  = 0x%X\r\n", frame.can_id);
	
	
	//6.Send message
	int i=0,j=0;
	char str_buf[12];
	char data[12] = {0};
    printf("You can always receive data, press Ctrl + C to exit\r\n");
    printf("You can enter up to 7 characters\r\n");
	printf("Send \"abcdef\" to open relays 1, 2, 3, 4, 5 and 6 respectively\r\n");
	printf("Send \"123456\" to close relays 1, 2, 3, 4, 5 and 6 respectivelyy\r\n");
	
	while(1)
	{
		setsockopt(s, SOL_CAN_RAW, CAN_RAW_FILTER, NULL, 0);
		
		printf("\n\nPlease enter the value you want to enter : ");
		scanf("%s", str_buf); 
		strcat(str_buf,"\n"); //Add newline
		j = 0;
		while(str_buf[j] != '\n')
		{
			frame.data[j] = str_buf[j];
			j++;
		}
		
		nbytes = write(s, &frame, sizeof(frame));
		if(nbytes != sizeof(frame)) 
		{
			printf("Send Error frame[0]!\r\n");
			system("sudo ifconfig can0 down");
			break;
		}
		//delay(10);
		
		setsockopt(s, SOL_CAN_RAW, CAN_RAW_FILTER, &rfilter, sizeof(rfilter));
		while(1)
		{
			nbytes = read(s, &frame, sizeof(frame));
			if(nbytes > 0) 
			{
				for(i = 0; (i<8) & (frame.data[i] != '\n'); i++)
					data[i] = frame.data[i];
				printf("The data received back is : %s\r\n", data);
				break;
			}
		}

		
		while(1)
		{
			nbytes = read(s, &frame, sizeof(frame));
			if(nbytes > 0) 
			{
				for(i=0;i<6;i++)
				{
					if(frame.data[0] & (0x01 << i))
						printf("Turn off Relay %d\r\n",i+1);
					if(frame.data[1] & (0x01 << i))
						printf("Turn on Relay %d\r\n",i+1);
				}
				break;
			}
		}
		
		delay(500);
		
		for(i = 0; i<8 ; i++)
			frame.data[i] = '\n';
		
	}
    
    //7.Close the socket and can0
    close(s);
    system("sudo ifconfig can0 down");
    return 0;
}

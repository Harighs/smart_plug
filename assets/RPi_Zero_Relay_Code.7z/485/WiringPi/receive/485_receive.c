#include <wiringSerial.h>
#include <wiringPi.h>
#include <stdio.h>
#include <stdlib.h>     //exit()
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <strings.h>
#include <sys/time.h>

// if use half-auto, EN_485 = LOW is Receiver, EN_485 = HIGH is Send
#define MODE 0 //mode = 0 is full-guto, mode = 1 is half-auto
#define EN_485 4
#define UART_DEV "/dev/ttyAMA0"

int fd;

void  Handler(int signo)
{
    //System Exit
    printf("\r\nHandler:serialClose \r\n");
    serialClose(fd);

    exit(0);
}

int main(void)
{
	printf("\r\n");
	if(wiringPiSetup() < 0) //use BCM2835 Pin number table
	{ 
	    printf("set wiringPi lib failed	!!! \r\n");
		printf("\r\n");
	    return 1;
    } 
	else 
	{
        printf("set wiringPi lib success  !!! \r\n");
    }

    pinMode(21, OUTPUT);
    pinMode(22, OUTPUT);
    pinMode(23, OUTPUT);
    pinMode(27, OUTPUT);
    pinMode(24, OUTPUT);
    pinMode(28, OUTPUT);
	
	digitalWrite(21, LOW);
    digitalWrite(22, LOW);
    digitalWrite(23, LOW);
	digitalWrite(27, LOW);
    digitalWrite(24, LOW);
    digitalWrite(28, LOW);
	
	
	 // Exception handling:ctrl + c
    signal(SIGINT, Handler);
	


    if((fd = serialOpen(UART_DEV, 115200)) < 0) {
        printf("serial err\n");
        return -1;
    }
    printf("use device %s\r\n", UART_DEV); 
	
	// serialFlush(fd);
    // serialPrintf(fd,"\r");

    printf("You can always receive data, press Ctrl + C to exit\r\n");
    char str;
	char data[20]={0};
	int i=0;
	char fun = 0x40;
	char fun1 = 0x40;
	
	
    for (;;) 
	{
		i = 0;
		while(1)
		{			
			str = serialGetchar(fd);
			
			if(str == '\n')				
				break;
				
			
			if(str < 128) // ascii
			{
				data[i] = str;
				i++;
			}
				
			switch(str)
			{
				case '1' :fun1 = fun1 & 0xfe ; fun = fun | 0x01 ; digitalWrite(21, LOW); break;
				case 'a' :fun = fun & 0xfe ; fun1 = fun1 | 0x01 ; digitalWrite(21, HIGH); break;
				
				case '2' :fun1 = fun1 & 0xfd ; fun = fun | 0x02 ; digitalWrite(22, LOW); break;
				case 'b' :fun = fun & 0xfd ; fun1 = fun1 | 0x02 ; digitalWrite(22, HIGH); break;
				
				case '3' :fun1 = fun1 & 0xfb ; fun = fun | 0x04 ; digitalWrite(23, LOW); break;
				case 'c' :fun = fun & 0xfb ; fun1 = fun1 | 0x04 ; digitalWrite(23, HIGH); break;
				
				case '4' :fun1 = fun1 & 0xf7 ; fun = fun | 0x08 ; digitalWrite(27, LOW); break;
				case 'd' :fun = fun & 0xf7 ; fun1 = fun1 | 0x08 ; digitalWrite(27, HIGH); break;
				
				case '5' :fun1 = fun1 & 0xef ; fun = fun | 0x10 ; digitalWrite(24, LOW); break;
				case 'e' :fun = fun & 0xef ; fun1 = fun1 | 0x10 ; digitalWrite(24, HIGH); break;
				
				case '6' :fun1 = fun1 & 0xdf ; fun = fun | 0x20 ; digitalWrite(28, LOW); break;
				case 'f' :fun = fun & 0xdf ; fun1 = fun1 | 0x20 ; digitalWrite(28, HIGH); break;
			}
			
			fflush(stdout); // Empty the output buffer and output the contents of the buffer
		}
		
		printf("\r\nThe data received is : %s\r\n", data);
		
		data[i] = '@';
		data[i+1] = fun;
		data[i+2] = fun1;
		data[i+3] = '\n';
		
		for(i=0;i<6;i++)
		{
			if(fun & (0x01 << i))
				printf("Turn off Relay %d\r\n",i+1);
			if(fun1 & (0x01 << i))
				printf("Turn on Relay %d\r\n",i+1);
		}
		

		
		// delay(200);

		serialPuts(fd, data);
		
		fun = 0x40;
		fun1 = 0x40;
		for(i = 0; i<20;i++)
			data[i] = 0;
		
		// delay(200);

    }
    return 0;
}

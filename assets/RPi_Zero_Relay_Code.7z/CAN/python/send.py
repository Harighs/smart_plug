import RPi.GPIO as GPIO
import serial
import os
import can
from can import Message

os.system('sudo ip link set can0 type can bitrate 100000')
os.system('sudo ifconfig can0 up')

can0 = can.interface.Bus(channel = 'can0', bustype = 'socketcan_ctypes')# socketcan_native

print("Wait for the receiver configuration to complete\n")
msg1 = can0.recv(20.0)
if msg1 is None:
    print('Timeout occurred, no message.')


print("You can always send data, press Ctrl + C to exit")
print("Send \"abcdef\" to open relays 1, 2, 3, 4, 5 and 6 respectively")
print("Send \"123456\" to close relays 1, 2, 3, 4, 5 and 6 respectivelyy")
while True:
    strInput = raw_input('\r\nenter some date:') 
    msg = Message(arbitration_id=0x123, data=strInput, extended_id=False)
    can0.send(msg)
    
    msg1 = can0.recv(10.0)
    if msg1 is None:
        print('Timeout occurred, no message.')
    print("The data received back is : "),msg1.data
    
    msg1 = can0.recv(10.0)
    if msg1 is None:
        print('Timeout occurred, no message.')
    
    for i in range(6):
        if(msg1.data[0] & (0x01 << i)):
            print("Relay "),i+1,("  off")
        if(msg1.data[1] & (0x01 << i)):
            print("Relay "),i+1,("  on")

os.system('sudo ifconfig can0 down')
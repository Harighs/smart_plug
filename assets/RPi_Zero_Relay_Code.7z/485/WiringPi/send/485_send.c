#include <wiringSerial.h>
#include <wiringPi.h>
#include <stdio.h>
#include <stdlib.h>     //exit()
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <strings.h>
#include <sys/time.h>

// if use half-auto, EN_485 = LOW is Receiver, EN_485 = HIGH is Send
#define MODE 0 //mode = 0 is full-guto, mode = 1 is half-auto
#define EN_485 4
#define UART_DEV "/dev/ttyAMA0"

int fd;

void  Handler(int signo)
{
    //System Exit
    printf("\r\nHandler:serialClose \r\n");
    serialClose(fd);

    exit(0);
}

int main(void)
{

    printf("use device %s\r\n", UART_DEV);
    if((fd = serialOpen(UART_DEV, 115200)) < 0) {
        printf("serial err\n");
        return -1;
    }

    // serialFlush(fd);
    // serialPrintf(fd,"\r");

    char str_buf[12];
    printf("You can always receive data, press Ctrl + C to exit\r\n");
    printf("You can enter up to %d characters\r\n", sizeof(str_buf));
	printf("Send \"abcdef\" to open relays 1, 2, 3, 4, 5 and 6 respectively\r\n");
	printf("Send \"123456\" to close relays 1, 2, 3, 4, 5 and 6 respectivelyy\r\n");
	
	int i=0;
	int o=0;
	char str;
	char fun[20] = {0};
    for(;;)
	{    
		
		printf("\n\nPlease enter the value you want to enter : ");
        scanf("%s", str_buf); 
        strcat(str_buf,"\n"); //Add newline
        serialPuts(fd, str_buf);
		
		i = 0;
		o = 0;
		while(1)
		{		
			str = serialGetchar(fd);
			if(str == '\n')
			{
				break;
			}
				
			if(str < 128) // ascii
			{
				str_buf[i] = str;
				i++;
			}
			str = 0;
			fflush(stdout); // Empty the output buffer and output the contents of the buffer
		}
		
		o=0;
		while(str_buf[o] != '@')
		{
			fun[o] = str_buf[o];
			o++;
		}
		printf("The data received back is : %s\r\n", fun);
		
		for(i=0;i<6;i++)
		{
			if(str_buf[o+1] & (0x01 << i))
				printf("Turn off Relay %d\r\n",i+1);
			if(str_buf[o+2] & (0x01 << i))
				printf("Turn on Relay %d\r\n",i+1);
		}
		
		str_buf[o+1] = 0x40;
		str_buf[o+2] = 0x40;
		
		for(i = 0; i<20;i++)
			fun[i] = 0;


			
    }
	
    serialClose(fd);
    return 0;
}

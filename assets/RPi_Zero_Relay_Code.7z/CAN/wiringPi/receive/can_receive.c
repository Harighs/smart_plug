#include <wiringSerial.h>
#include <wiringPi.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <strings.h>
#include <sys/time.h>

#include <stdlib.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <linux/can.h>
#include <linux/can/raw.h>


int main()
{
	
	printf("\r\n");
	if(wiringPiSetup() < 0) //use BCM2835 Pin number table
	{ 
	    printf("set wiringPi lib failed	!!! \r\n");
		printf("\r\n");
	    return 1;
    } 
	else 
	{
        printf("set wiringPi lib success  !!! \r\n");
    }

    pinMode(21, OUTPUT);
    pinMode(22, OUTPUT);
    pinMode(23, OUTPUT);
    pinMode(27, OUTPUT);
    pinMode(24, OUTPUT);
    pinMode(28, OUTPUT);
	
	digitalWrite(21, LOW);
    digitalWrite(22, LOW);
    digitalWrite(23, LOW);
	digitalWrite(27, LOW);
    digitalWrite(24, LOW);
    digitalWrite(28, LOW);
	
	
    int ret;
    int s, nbytes;
    struct sockaddr_can addr;
    struct ifreq ifr;
    struct can_frame frame;
    
    memset(&frame, 0, sizeof(struct can_frame));
    
    system("sudo ip link set can0 type can bitrate 100000");
    system("sudo ifconfig can0 up");
    printf("this is a can receive demo\r\n");
    
    //1.Create socket
    s = socket(PF_CAN, SOCK_RAW, CAN_RAW);
    if (s < 0) {
        perror("socket PF_CAN failed");
        return 1;
    }
    
    //2.Specify can0 device
    strcpy(ifr.ifr_name, "can0");
    ret = ioctl(s, SIOCGIFINDEX, &ifr);
    if (ret < 0) {
        perror("ioctl failed");
        return 1;
    }

    //3.Bind the socket to can0
    addr.can_family = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;
    ret = bind(s, (struct sockaddr *)&addr, sizeof(addr));
    if (ret < 0) {
        perror("bind failed");
        return 1;
    }
    
    //4.Define receive rules
    struct can_filter rfilter[1];
    rfilter[0].can_id = 0x123;
    rfilter[0].can_mask = CAN_SFF_MASK;
    setsockopt(s, SOL_CAN_RAW, CAN_RAW_FILTER, &rfilter, sizeof(rfilter));
	
	setsockopt(s, SOL_CAN_RAW, CAN_RAW_FILTER, NULL, 0);
	frame.can_id = 0x123;
	frame.can_dlc = 8;
	frame.data[0] = 0;
    frame.data[1] = 10;
	frame.data[2] = 10;
	frame.data[3] = 10;
	frame.data[4] = 10;
	frame.data[5] = 10;
	frame.data[6] = 10;
	frame.data[7] = 10;


	
	int i = 0;
	char data[12] ;
	char fun = 0x00;
	char fun1 = 0x00;
	
    //5.Receive data and exit
   while(1) {
		setsockopt(s, SOL_CAN_RAW, CAN_RAW_FILTER, &rfilter, sizeof(rfilter));
		i=0;
		while(1)
		{
			nbytes = read(s, &frame, sizeof(frame));
			if(nbytes > 0) 
			{
				for(i = 0;i<8;i++)
				{
					data[i] = frame.data[i];
					
					if(frame.data[i] == '\n')
						break;	

					// delay(10);
				}
				break;
			}
		}
		
		printf("\r\nThe data received is : %s", data);
		for(int j=0; j<i;j++)
		{
			switch(data[j])
			{
				case '1' : printf("Turn off Relay 1\r\n"); fun1 = fun1 & 0xfe ; fun = fun | 0x01 ; digitalWrite(21, LOW); break;
				case 'a' : printf("Turn on Relay 1\r\n"); fun = fun & 0xfe ; fun1 = fun1 | 0x01 ; digitalWrite(21, HIGH); break;
				
				case '2' : printf("Turn off Relay 2\r\n"); fun1 = fun1 & 0xfd ; fun = fun | 0x02 ; digitalWrite(22, LOW); break;
				case 'b' : printf("Turn on Relay 2\r\n"); fun = fun & 0xfd ; fun1 = fun1 | 0x02 ; digitalWrite(22, HIGH); break;
				
				case '3' : printf("Turn off Relay 3\r\n"); fun1 = fun1 & 0xfb ; fun = fun | 0x04 ; digitalWrite(23, LOW); break;
				case 'c' : printf("Turn on Relay 3\r\n"); fun = fun & 0xfb ; fun1 = fun1 | 0x04 ; digitalWrite(23, HIGH); break;
				
				case '4' : printf("Turn off Relay 4\r\n"); fun1 = fun1 & 0xf7 ; fun = fun | 0x08 ; digitalWrite(27, LOW); break;
				case 'd' : printf("Turn on Relay 4\r\n"); fun = fun & 0xf7 ; fun1 = fun1 | 0x08 ; digitalWrite(27, HIGH); break;
				
				case '5' : printf("Turn off Relay 5\r\n"); fun1 = fun1 & 0xef ; fun = fun | 0x10 ; digitalWrite(24, LOW); break;
				case 'e' : printf("Turn on Relay 5\r\n"); fun = fun & 0xef ; fun1 = fun1 | 0x10 ; digitalWrite(24, HIGH); break;
				
				case '6' : printf("Turn off Relay 6\r\n"); fun1 = fun1 & 0xdf ; fun = fun | 0x20 ; digitalWrite(28, LOW); break;
				case 'f' : printf("Turn on Relay 6\r\n"); fun = fun & 0xdf ; fun1 = fun1 | 0x20 ; digitalWrite(28, HIGH); break;
			}
		}
		
		
		
		delay(500);
		
		setsockopt(s, SOL_CAN_RAW, CAN_RAW_FILTER, NULL, 0);
		delay(10);
		for(int j=0; j<i;j++)
		{
			frame.data[j] = data[j];
		}
			
		nbytes = write(s, &frame, sizeof(frame)); 
		
		if(nbytes != sizeof(frame)) 
		{
			printf("Send Error frame[0]!\r\n");
			system("sudo ifconfig can0 down");
		}
		delay(100);
		
		frame.data[0] = fun;
		frame.data[1] = fun1;
		frame.data[2] = '\n';
		nbytes = write(s, &frame, sizeof(frame)); 
		if(nbytes != sizeof(frame)) 
		{
			printf("Send Error frame[0]!\r\n");
			system("sudo ifconfig can0 down");
		}
		
		for(i = 0; i<8 ; i++)
			frame.data[i] = '\n';
		
    }
    
    //6.Close the socket and can0
    close(s);
    system("sudo ifconfig can0 down");
    
    return 0;
}
